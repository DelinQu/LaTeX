from sklearn.svm import SVC
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from matplotlib import colors, rcParams
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

# 初始化库参数
rcParams['font.sans-serif'] = [u'SimHei']
rcParams['axes.unicode_minus'] = False
np.set_printoptions(2, suppress=True)

# 载入数据并分割测试集与训练集
X = np.array([np.array(Image.open(f"./YALE/f{i}/{i}_s{j}.bmp")).reshape(-1)
              for i in range(1, 16) for j in range(1, 12)])
y = np.arange(15).repeat(11)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

# 进行标准化处理
sts = StandardScaler()
sts.fit(X_train)
X_train = sts.transform(X_train)
X_test = sts.transform(X_test)

# 对训练集进行PCA降维处理
pca = PCA(2)
pca.fit(X_train, y_train)
X_train = pca.transform(X_train)
X_test = pca.transform(X_test)
print(pca.explained_variance_ratio_)

# 坐标系初始化
x1_min, x1_max = X_test[:, 0].min(), X_test[:, 0].max()
x2_min, x2_max = X_test[:, 1].min(), X_test[:, 1].max()
plt.figure('YALE')
plt.xlim(x1_min, x1_max)
plt.ylim(x2_min, x2_max)
plt.xlabel('x', fontsize=13)
plt.ylabel('y', fontsize=13)

for c in np.arange(0.1, 5, 0.1):
    # 训练SVM
    clf = SVC(kernel='rbf', gamma='auto', C=c)  # 使用sklearn库中的SVC
    clf.fit(X_train, y_train)

    # 通过SVC涂色并显示测试集各样本的分布
    x1, x2 = np.mgrid[x1_min:x1_max:300j, x2_min:x2_max:300j]
    grid_test = np.stack((x1.flat, x2.flat), axis=1)
    grid_hat = clf.predict(grid_test).reshape(x1.shape)

    cm_light = colors.ListedColormap([f'#{45 * min(i % 5, 200):02X}'
                                      f'{45 * min(max((i % 5 - 200), 0), 200):02X}'
                                      f'{45 * min(max((i % 5 - 400), 0), 200):02X}'
                                      for i in range(15)])
    plt.pcolormesh(x1, x2, grid_hat, cmap=cm_light)
    # plt.scatter(X_test[:, 0], X_test[:, 1], c=y_test)

    print("Train_score:{:.2f}\nTest_score:{:.2f}".format(clf.score(X_train, y_train), clf.score(X_test, y_test)))

    plt.show()
